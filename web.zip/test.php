<?php
include("partials/navbar.php");
?>





<?php
include("partials/footer.php");
?>